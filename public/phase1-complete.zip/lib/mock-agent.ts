import { prisma } from "./prisma";

export type AgentMode = "Discuss" | "Plan" | "Build" | "Improve" | "Debug";

interface AgentContext {
  mode: AgentMode;
  content: string;
  projectId: string;
  chatMessages: { role: string; content: string; mode: string }[];
}

const PLAN_QUESTIONS = [
  "What is the primary purpose of this application? (e.g., e-commerce, social media, dashboard)",
  "What are the key features you need in the MVP? Please list 3-5 core features.",
  "Do you have any technology preferences or constraints? (e.g., specific database, hosting requirements)",
];

const MOCK_PLAN = `## Project Plan

### Architecture
- **Frontend**: React with TypeScript + TailwindCSS
- **Backend**: Node.js/Express REST API
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: NextAuth.js with Google OAuth

### Milestones

#### Phase 1: Foundation (Week 1-2)
- Project scaffolding and configuration
- Database schema design and migrations
- Authentication system setup
- Basic API endpoints

#### Phase 2: Core Features (Week 3-4)
- Main UI components and layouts
- CRUD operations for primary entities
- Form validation and error handling
- API integration with frontend

#### Phase 3: Polish (Week 5-6)
- Responsive design refinements
- Performance optimization
- Testing and bug fixes
- Deployment configuration

### Estimated Timeline: 6 weeks

Say **"Build it"** to start the build process.`;

function generateBuildLogs(): { level: string; message: string }[] {
  return [
    { level: "INFO", message: "Starting build process..." },
    { level: "INFO", message: "Installing dependencies..." },
    { level: "INFO", message: "npm install: added 847 packages in 12.3s" },
    { level: "INFO", message: "Generating database schema..." },
    { level: "INFO", message: "CREATE TABLE users (id VARCHAR PRIMARY KEY, ...)" },
    { level: "INFO", message: "CREATE TABLE sessions (session_token VARCHAR UNIQUE, ...)" },
    { level: "INFO", message: "CREATE TABLE projects (id VARCHAR PRIMARY KEY, ...)" },
    { level: "SUCCESS", message: "Database schema pushed successfully" },
    { level: "INFO", message: "Scaffolding project structure..." },
    { level: "INFO", message: "Created: app/layout.tsx" },
    { level: "INFO", message: "Created: app/page.tsx" },
    { level: "INFO", message: "Created: app/api/auth/[...nextauth]/route.ts" },
    { level: "INFO", message: "Created: components/workspace/chat-panel.tsx" },
    { level: "INFO", message: "Created: components/workspace/console-panel.tsx" },
    { level: "WARN", message: "No .env.local file found, using defaults" },
    { level: "INFO", message: "Building frontend assets..." },
    { level: "INFO", message: "next build - compiling..." },
    { level: "INFO", message: "127 modules transformed" },
    { level: "INFO", message: ".next/static/chunks/main-a1b2c3.js  142.35 kB" },
    { level: "INFO", message: ".next/static/css/app-e5f6g7.css  18.74 kB" },
    { level: "SUCCESS", message: "Frontend build completed in 3.2s" },
    { level: "INFO", message: "Running tests..." },
    { level: "INFO", message: "PASS  tests/auth.test.ts (3 tests)" },
    { level: "INFO", message: "PASS  tests/api.test.ts (7 tests)" },
    { level: "INFO", message: "PASS  tests/components.test.ts (12 tests)" },
    { level: "SUCCESS", message: "All 22 tests passed" },
    { level: "INFO", message: "Starting server on port 5000..." },
    { level: "SUCCESS", message: "Build complete! Application is running." },
  ];
}

function getDiscussResponse(content: string): string {
  const lower = content.toLowerCase();
  if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey")) {
    return "Hello! I'm your AI workspace assistant. I can help you discuss ideas, plan your project, build it, improve existing code, or debug issues. Select a mode from the dropdown to get started!\n\nCurrently in **Discuss** mode — feel free to ask me anything about your project.";
  }
  if (lower.includes("what can you do") || lower.includes("help")) {
    return `Here's what I can do in each mode:\n\n- **Discuss**: General conversation about your project ideas and requirements\n- **Plan**: I'll ask you targeted questions and create a detailed project plan\n- **Build**: Execute the plan and generate build artifacts (say "Build it" to trigger)\n- **Improve**: Analyze your project spec and suggest enhancements\n- **Debug**: Help troubleshoot issues with guided debugging steps\n\nSwitch modes using the selector above the chat input.`;
  }
  if (lower.includes("database") || lower.includes("sql") || lower.includes("schema")) {
    return "Great question about databases! For most web applications, I'd recommend:\n\n1. **PostgreSQL** for relational data with complex queries\n2. **Prisma ORM** for type-safe database operations in TypeScript\n3. A well-normalized schema with proper relations\n\nSwitch to **Plan** mode and I'll help you design the perfect schema for your needs.";
  }
  return `That's an interesting point! Here are my thoughts:\n\nBased on what you've described, I'd recommend breaking this down into smaller, manageable components. Each component should have a single responsibility and clear interfaces.\n\nWould you like me to:\n1. **Plan** this out in detail? (Switch to Plan mode)\n2. **Build** a prototype? (Switch to Build mode after planning)\n3. Continue **discussing** the approach?\n\nI'm here to help however you need!`;
}

function getImproveResponse(specJson: unknown): string {
  if (!specJson) {
    return "I don't see a project spec yet. Here's what I'd recommend:\n\n1. Switch to **Plan** mode to create a detailed project specification\n2. The spec will be saved to your project's Database tab\n3. Then come back to **Improve** mode and I'll analyze it for enhancements";
  }
  return `I've analyzed your project spec and here are my recommendations:\n\n### Performance Improvements\n- Add database connection pooling\n- Implement response caching for frequently accessed data\n- Use lazy loading for frontend components\n\n### Security Enhancements\n- Add rate limiting to API endpoints\n- Implement CSRF protection\n- Set up Content Security Policy headers\n\n### UX Improvements\n- Add loading skeletons instead of spinners\n- Implement optimistic updates for better perceived performance\n- Add keyboard shortcuts for power users\n\nWould you like me to elaborate on any of these suggestions?`;
}

function getDebugResponse(content: string): string {
  const lower = content.toLowerCase();
  if (lower.includes("error") || lower.includes("bug") || lower.includes("crash")) {
    return `Let me help you debug that. Here's my systematic approach:\n\n### Step 1: Reproduce\n- Can you reproduce the error consistently?\n- What are the exact steps to trigger it?\n\n### Step 2: Isolate\n- Check the **Console** tab for error logs\n- Look at the **Database** tab to verify data integrity\n\n### Step 3: Diagnose\nCommon causes:\n1. **State management bug** — Component state not syncing properly\n2. **API error** — Backend returning unexpected response format\n3. **Race condition** — Async operations completing out of order\n\nCan you share more details about the error message you're seeing?`;
  }
  return `I'm in debug mode and ready to help! To get started, tell me:\n\n1. **What's happening?** — Describe the unexpected behavior\n2. **What should happen?** — Describe the expected behavior\n3. **When does it happen?** — Steps to reproduce\n4. **Error messages?** — Any console errors or stack traces\n\nYou can also check the **Console tab** for live logs and the **Database tab** to verify data.`;
}

export async function processMessage(ctx: AgentContext): Promise<{
  response: string;
  shouldCreateJob: boolean;
  specUpdate?: Record<string, unknown>;
}> {
  const { mode, content, projectId, chatMessages } = ctx;

  switch (mode) {
    case "Discuss":
      return { response: getDiscussResponse(content), shouldCreateJob: false };

    case "Plan": {
      const planUserMessages = chatMessages.filter((m) => m.role === "user" && m.mode === "Plan");
      if (planUserMessages.length <= 1) {
        return {
          response: `Great, let's plan your project! I need to understand your requirements first.\n\n**Question 1 of 3:**\n${PLAN_QUESTIONS[0]}`,
          shouldCreateJob: false,
        };
      }
      if (planUserMessages.length === 2) {
        return {
          response: `Thanks for that context!\n\n**Question 2 of 3:**\n${PLAN_QUESTIONS[1]}`,
          shouldCreateJob: false,
        };
      }
      if (planUserMessages.length === 3) {
        return {
          response: `Excellent, one more question!\n\n**Question 3 of 3:**\n${PLAN_QUESTIONS[2]}`,
          shouldCreateJob: false,
        };
      }
      const specJson = {
        purpose: planUserMessages[1]?.content || "Not specified",
        features: planUserMessages[2]?.content || "Not specified",
        techPreferences: planUserMessages[3]?.content || "Not specified",
        createdAt: new Date().toISOString(),
      };
      return {
        response: `Perfect! Based on your answers, here's the project plan:\n\n${MOCK_PLAN}`,
        shouldCreateJob: false,
        specUpdate: specJson,
      };
    }

    case "Build": {
      const trimmed = content.trim().toLowerCase();
      if (trimmed === "build it") {
        return {
          response: "**Build started!** Switch to the **Console** tab to watch the live build logs.\n\nI'm setting up the project structure, installing dependencies, configuring the database, and building the frontend assets.",
          shouldCreateJob: true,
        };
      }
      return {
        response: 'I\'m ready to build! To start the build process:\n\n1. First, switch to **Plan** mode and create a project plan\n2. Then come back to **Build** mode\n3. Say **"Build it"** to kick off the build\n\nThe build will generate realistic job logs that you can monitor in the **Console** tab.',
        shouldCreateJob: false,
      };
    }

    case "Improve": {
      const project = await prisma.project.findUnique({ where: { id: projectId } });
      return {
        response: getImproveResponse(project?.specJson),
        shouldCreateJob: false,
      };
    }

    case "Debug":
      return { response: getDebugResponse(content), shouldCreateJob: false };

    default:
      return {
        response: "Please select a valid mode: Discuss, Plan, Build, Improve, or Debug.",
        shouldCreateJob: false,
      };
  }
}

export async function createBuildJob(projectId: string): Promise<string> {
  const job = await prisma.job.create({
    data: { projectId, status: "RUNNING" },
  });
  const logs = generateBuildLogs();

  (async () => {
    for (let i = 0; i < logs.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      await prisma.jobLog.create({
        data: {
          jobId: job.id,
          level: logs[i].level,
          message: logs[i].message,
        },
      });
    }
    await prisma.job.update({
      where: { id: job.id },
      data: { status: "COMPLETED" },
    });
  })();

  return job.id;
}
