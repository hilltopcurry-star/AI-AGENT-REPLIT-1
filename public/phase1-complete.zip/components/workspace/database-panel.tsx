"use client";

import { useQuery } from "@tanstack/react-query";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Database } from "lucide-react";

interface Project {
  id: string;
  name: string;
  specJson: Record<string, string> | null;
  createdAt: string;
}

interface DatabasePanelProps {
  projectId: string;
}

export function DatabasePanel({ projectId }: DatabasePanelProps) {
  const { data: project } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
    queryFn: () => fetch(`/api/projects/${projectId}`).then((r) => r.json()),
  });

  const spec = project?.specJson;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
        <Database className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium text-foreground">
          Project Data
        </span>
      </div>

      <ScrollArea className="flex-1 p-4">
        {spec ? (
          <div className="space-y-4">
            <div>
              <Badge variant="secondary" className="mb-3" data-testid="badge-spec-status">
                Spec Generated
              </Badge>
            </div>
            <div className="space-y-3">
              {Object.entries(spec).map(([key, value]) => (
                <div
                  key={key}
                  className="bg-card border border-card-border rounded-lg p-3"
                  data-testid={`data-spec-${key}`}
                >
                  <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">
                    {key.replace(/([A-Z])/g, " $1").trim()}
                  </div>
                  <div className="text-sm text-foreground">{String(value)}</div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center">
              <Database className="h-10 w-10 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No project data yet</p>
              <p className="text-xs mt-1">
                Use Plan mode in Chat to generate a project spec
              </p>
            </div>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
