"use client";

import { Globe } from "lucide-react";

export function PreviewPanel() {
  return (
    <div className="flex-1 flex items-center justify-center text-muted-foreground">
      <div className="text-center">
        <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <h3 className="text-lg font-medium text-foreground mb-2">
          Live Preview
        </h3>
        <p className="text-sm max-w-sm">
          The live preview will display your application here once a build is
          completed. This feature is available in Phase 2.
        </p>
      </div>
    </div>
  );
}
