"use client";

import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Terminal, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

interface Job {
  id: string;
  status: string;
  createdAt: string;
  _count: { logs: number };
}

interface LogEntry {
  id: string;
  level: string;
  message: string;
  createdAt: string;
}

interface ConsolePanelProps {
  projectId: string;
  activeJobId?: string | null;
}

export function ConsolePanel({ projectId, activeJobId }: ConsolePanelProps) {
  const [streamingLogs, setStreamingLogs] = useState<LogEntry[]>([]);
  const [jobStatus, setJobStatus] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: jobs } = useQuery<Job[]>({
    queryKey: ["/api/projects", projectId, "jobs"],
    queryFn: () =>
      fetch(`/api/projects/${projectId}/jobs`).then((r) => r.json()),
  });

  const currentJobId = activeJobId || jobs?.[0]?.id;

  useEffect(() => {
    if (!currentJobId) return;

    setStreamingLogs([]);
    setJobStatus(null);

    const eventSource = new EventSource(`/api/jobs/${currentJobId}/logs`);

    eventSource.onmessage = (event) => {
      const data = event.data;
      if (data === "[DONE]") {
        eventSource.close();
        return;
      }

      try {
        const parsed = JSON.parse(data);
        if (parsed.type === "job_done") {
          setJobStatus(parsed.status);
          eventSource.close();
        } else {
          setStreamingLogs((prev) => [...prev, parsed]);
        }
      } catch {
        // skip
      }
    };

    eventSource.onerror = () => {
      eventSource.close();
    };

    return () => eventSource.close();
  }, [currentJobId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [streamingLogs]);

  const getLevelIcon = (level: string) => {
    switch (level) {
      case "SUCCESS":
        return <CheckCircle className="h-3.5 w-3.5 text-green-500" />;
      case "WARN":
        return <AlertTriangle className="h-3.5 w-3.5 text-yellow-500" />;
      case "ERROR":
        return <XCircle className="h-3.5 w-3.5 text-red-500" />;
      default:
        return <Terminal className="h-3.5 w-3.5 text-muted-foreground" />;
    }
  };

  const getLevelClass = (level: string) => {
    switch (level) {
      case "SUCCESS":
        return "text-green-400";
      case "WARN":
        return "text-yellow-400";
      case "ERROR":
        return "text-red-400";
      default:
        return "text-foreground/80";
    }
  };

  if (!currentJobId) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground font-mono">
        <div className="text-center">
          <Terminal className="h-10 w-10 mx-auto mb-3 opacity-50" />
          <p className="text-sm">No build jobs yet</p>
          <p className="text-xs mt-1">
            Switch to Chat → Build mode and say &quot;Build it&quot;
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[hsl(222,47%,5%)] text-white font-mono text-sm">
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Terminal className="h-4 w-4" />
          <span className="text-xs opacity-70">
            Job {currentJobId.slice(0, 8)}...
          </span>
        </div>
        {jobStatus && (
          <Badge
            variant={jobStatus === "COMPLETED" ? "default" : "destructive"}
            className="text-xs"
            data-testid="badge-job-status"
          >
            {jobStatus}
          </Badge>
        )}
      </div>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-1">
          {streamingLogs.map((log, i) => (
            <div
              key={log.id || i}
              className="flex items-start gap-2"
              data-testid={`log-entry-${i}`}
            >
              {getLevelIcon(log.level)}
              <span className={`${getLevelClass(log.level)} text-xs`}>
                {log.message}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
