"use client";

import { useState, useRef, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { ModeSelector } from "./mode-selector";
import { Send, Bot, User, Loader2 } from "lucide-react";

interface Message {
  id: string;
  chatId: string;
  role: string;
  content: string;
  mode: string;
  createdAt: string;
}

interface ChatPanelProps {
  chatId: string | null;
  projectId: string;
  onJobCreated?: (jobId: string) => void;
}

export function ChatPanel({ chatId, projectId, onJobCreated }: ChatPanelProps) {
  const [mode, setMode] = useState("Discuss");
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const qc = useQueryClient();

  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/chats", chatId, "messages"],
    queryFn: () =>
      chatId
        ? fetch(`/api/chats/${chatId}/messages`).then((r) => r.json())
        : Promise.resolve([]),
    enabled: !!chatId,
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, streamingContent]);

  const handleSend = async () => {
    if (!input.trim() || !chatId || isSending) return;

    const content = input.trim();
    setInput("");
    setIsSending(true);
    setStreamingContent("");

    try {
      const res = await fetch(`/api/chats/${chatId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, mode }),
      });

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6);
            if (data === "[DONE]") break;

            try {
              const parsed = JSON.parse(data);
              if (parsed.type === "token") {
                setStreamingContent((prev) => prev + parsed.content);
              } else if (parsed.type === "assistant_message") {
                setStreamingContent("");
                if (parsed.jobId && onJobCreated) {
                  onJobCreated(parsed.jobId);
                }
              }
            } catch {
              // skip malformed JSON
            }
          }
        }
      }

      qc.invalidateQueries({ queryKey: ["/api/chats", chatId, "messages"] });
    } catch (err) {
      console.error("Send failed:", err);
    } finally {
      setIsSending(false);
      setStreamingContent("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!chatId) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Bot className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p>Create or select a chat to get started</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 rounded-lg" />
            ))}
          </div>
        ) : !messages?.length && !streamingContent ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center">
              <Bot className="h-10 w-10 mx-auto mb-3 opacity-50" />
              <p className="text-sm">Send a message to start the conversation</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4 pb-4">
            {messages?.map((msg) => (
              <div
                key={msg.id}
                data-testid={`message-${msg.role}-${msg.id}`}
                className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""}`}
              >
                {msg.role !== "user" && (
                  <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}
                <div
                  className={`rounded-lg px-3 py-2 max-w-[80%] text-sm whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-card border border-card-border"
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === "user" && (
                  <div className="flex-shrink-0 w-7 h-7 rounded-full bg-muted flex items-center justify-center">
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))}
            {streamingContent && (
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="rounded-lg px-3 py-2 max-w-[80%] text-sm whitespace-pre-wrap bg-card border border-card-border">
                  {streamingContent}
                  <span className="inline-block w-1.5 h-4 bg-primary animate-pulse ml-0.5" />
                </div>
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      <div className="border-t border-border p-3">
        <div className="flex items-end gap-2">
          <ModeSelector mode={mode} onModeChange={setMode} />
          <Textarea
            data-testid="input-chat-message"
            placeholder={`Message in ${mode} mode...`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="resize-none min-h-[40px] max-h-[120px] text-sm"
            rows={1}
            disabled={isSending}
          />
          <Button
            data-testid="button-send-message"
            size="icon"
            onClick={handleSend}
            disabled={!input.trim() || isSending}
            className="h-10 w-10 flex-shrink-0"
          >
            {isSending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
