"use client";

import { Code2 } from "lucide-react";

export function PublishPanel() {
  return (
    <div className="flex-1 flex items-center justify-center text-muted-foreground">
      <div className="text-center">
        <Code2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <h3 className="text-lg font-medium text-foreground mb-2">
          Publish & Deploy
        </h3>
        <p className="text-sm max-w-sm">
          Deploy your application to Railway, Vercel, or any cloud provider.
          Configure environment variables, domains, and scaling options. Coming
          in Phase 2.
        </p>
      </div>
    </div>
  );
}
