# AI Workspace

## Overview
AI-powered development workspace built with Next.js App Router. Features 5 workspace tabs (Chat, Preview, Console, Database, Publish) with a mock AI agent for Phase 1.

## Architecture
- **Framework**: Next.js 16 (App Router) + TypeScript (strict)
- **Database**: PostgreSQL via Prisma ORM
- **Auth**: NextAuth.js (Auth.js v5 beta) with Google OAuth + Prisma adapter
- **Payments**: Stripe (Phase 2)
- **UI**: Radix UI + Tailwind CSS + shadcn/ui components
- **State**: TanStack React Query

## Project Structure
```
app/                    # Next.js App Router pages + API routes
  api/                  # API routes (projects, chats, jobs, auth, health)
  projects/             # Projects list + workspace pages
  page.tsx              # Landing page
  layout.tsx            # Root layout with providers
components/
  ui/                   # shadcn/ui components
  workspace/            # Workspace-specific components (chat, console, database, etc.)
  providers.tsx         # React Query + NextAuth + Theme providers
  theme-provider.tsx    # Dark/light mode
hooks/                  # Custom hooks (use-toast)
lib/
  auth.ts               # NextAuth configuration
  prisma.ts             # Prisma client singleton
  mock-agent.ts         # Mock AI agent with 5 modes
  query-client.ts       # TanStack Query client + apiRequest helper
prisma/
  schema.prisma         # Database schema
```

## Database Schema (Prisma)
- User, Account, Session, VerificationToken (NextAuth standard)
- Project (userId, name, specJson)
- Chat (projectId)
- Message (chatId, role, content, mode)
- Job (projectId, status)
- JobLog (jobId, level, message)

## Key Features
- **5 Agent Modes**: Discuss, Plan, Build, Improve, Debug
- **Strict Build Gate**: Job only created when mode=Build AND content is exactly "Build it" (case-insensitive, trimmed)
- **SSE Streaming**: Chat messages streamed word-by-word, job logs streamed in real-time (with disconnect handling)
- **Multi-tenant**: All queries scoped by userId with ownership checks
- **5 Workspace Tabs**: Chat, Preview (placeholder), Console, Database, Publish (placeholder)
- **Project Rename**: Inline editable project name in sidebar (PATCH /api/projects/[id])

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Used as NextAuth secret fallback
- `GOOGLE_CLIENT_ID` - Google OAuth client ID
- `GOOGLE_CLIENT_SECRET` - Google OAuth client secret
- `NEXTAUTH_SECRET` - NextAuth.js secret (optional, falls back to SESSION_SECRET)

## Running
- Workflow: `npx next dev -p 5000 --hostname 0.0.0.0`
- Database: `npx prisma db push` to sync schema
