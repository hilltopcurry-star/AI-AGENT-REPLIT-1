import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { processMessage, createBuildJob } from "@/lib/mock-agent";
import type { AgentMode } from "@/lib/mock-agent";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const chat = await prisma.chat.findUnique({
    where: { id },
    include: { project: { select: { userId: true } } },
  });

  if (!chat || chat.project.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const messages = await prisma.message.findMany({
    where: { chatId: id },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json(messages);
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const chat = await prisma.chat.findUnique({
    where: { id },
    include: {
      project: { select: { userId: true } },
      messages: { orderBy: { createdAt: "asc" } },
    },
  });

  if (!chat || chat.project.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await req.json();
  const { content, mode = "Discuss" } = body as {
    content: string;
    mode?: AgentMode;
  };

  if (!content || typeof content !== "string") {
    return NextResponse.json({ error: "Content required" }, { status: 400 });
  }

  const userMessage = await prisma.message.create({
    data: { chatId: id, role: "user", content, mode },
  });

  const chatMessages = [
    ...chat.messages.map((m) => ({
      role: m.role,
      content: m.content,
      mode: m.mode,
    })),
    { role: "user", content, mode },
  ];

  const result = await processMessage({
    mode: mode as AgentMode,
    content,
    projectId: chat.projectId,
    chatMessages,
  });

  if (result.specUpdate) {
    await prisma.project.update({
      where: { id: chat.projectId },
      data: { specJson: result.specUpdate },
    });
  }

  let jobId: string | null = null;
  if (result.shouldCreateJob) {
    jobId = await createBuildJob(chat.projectId);
  }

  const assistantMessage = await prisma.message.create({
    data: { chatId: id, role: "assistant", content: result.response, mode },
  });

  const encoder = new TextEncoder();
  let cancelled = false;

  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(
        encoder.encode(
          `data: ${JSON.stringify({ type: "user_message", message: userMessage })}\n\n`
        )
      );

      const words = result.response.split(" ");
      let i = 0;

      function sendWord() {
        if (cancelled) return;
        if (i < words.length) {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ type: "token", content: words[i] + " " })}\n\n`
            )
          );
          i++;
          setTimeout(sendWord, 20);
        } else {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({
                type: "assistant_message",
                message: assistantMessage,
                jobId,
              })}\n\n`
            )
          );
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
        }
      }

      setTimeout(sendWord, 50);
    },
    cancel() {
      cancelled = true;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
