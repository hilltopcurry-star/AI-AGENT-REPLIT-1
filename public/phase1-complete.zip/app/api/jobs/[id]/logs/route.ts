import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const job = await prisma.job.findUnique({
    where: { id },
    include: { project: { select: { userId: true } } },
  });

  if (!job || job.project.userId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const encoder = new TextEncoder();
  let cancelled = false;

  const stream = new ReadableStream({
    async start(controller) {
      let lastCount = 0;

      const poll = async () => {
        if (cancelled) return;

        try {
          const logs = await prisma.jobLog.findMany({
            where: { jobId: id },
            orderBy: { createdAt: "asc" },
            skip: lastCount,
          });

          for (const log of logs) {
            if (cancelled) return;
            controller.enqueue(
              encoder.encode(`data: ${JSON.stringify(log)}\n\n`)
            );
            lastCount++;
          }

          const currentJob = await prisma.job.findUnique({
            where: { id },
            select: { status: true },
          });

          if (
            currentJob?.status === "COMPLETED" ||
            currentJob?.status === "FAILED"
          ) {
            controller.enqueue(
              encoder.encode(
                `data: ${JSON.stringify({ type: "job_done", status: currentJob.status })}\n\n`
              )
            );
            controller.close();
            return;
          }

          if (!cancelled) {
            setTimeout(poll, 500);
          }
        } catch {
          if (!cancelled) {
            controller.close();
          }
        }
      };

      poll();
    },
    cancel() {
      cancelled = true;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
