import type { Express, Request, Response } from "express";
import { isAuthenticated } from "./replit_integrations/auth";
import { storage } from "./storage";

function getUserId(req: Request): number {
  return (req.session as any).userId;
}

export function registerRoutes(app: Express) {
  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.get("/api/projects", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const projectList = await storage.getUserProjects(userId);
      res.json(projectList);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { name, description } = req.body;
      if (!name || typeof name !== "string") {
        return res.status(400).json({ message: "Project name is required" });
      }
      const project = await storage.createProject({
        userId,
        name,
        description: description || null,
      });
      res.json(project);
    } catch (err) {
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      res.json(project);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.delete("/api/projects/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      await storage.deleteProject(projectId);
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  app.get("/api/projects/:id/messages", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const msgs = await storage.getProjectMessages(projectId);
      res.json(msgs);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/projects/:id/messages", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const { content, agentMode } = req.body;
      if (!content || typeof content !== "string") {
        return res.status(400).json({ message: "Content is required" });
      }
      const validModes = ["discuss", "plan", "build"];
      const mode = validModes.includes(agentMode) ? agentMode : "discuss";

      const userMessage = await storage.createMessage({
        projectId,
        role: "user",
        content,
        agentMode: mode,
      });

      let assistantContent = "";
      if (mode === "discuss") {
        assistantContent = `[Discuss Mode] I've analyzed your request: "${content}"\n\nHere are my thoughts:\n- This is a mock response in Discuss mode\n- In Phase-2, this will use AI to provide real analysis\n- You can switch to Plan mode to create an action plan\n- Or switch to Build mode when you're ready to generate code`;
      } else if (mode === "plan") {
        assistantContent = `[Plan Mode] Here's a plan based on your request: "${content}"\n\n**Action Plan:**\n1. Analyze requirements\n2. Design component structure\n3. Implement core logic\n4. Add styling and interactions\n5. Test and validate\n\n*This is a mock plan. In Phase-2, AI will generate real, detailed plans.*\n\nWhen you're ready, switch to Build mode and say "Build it" to start the build process.`;
      } else if (mode === "build") {
        assistantContent = `[Build Mode] Received your message: "${content}"\n\n⚠️ To trigger a build, you must say **"Build it"** in Build mode.\n\n*Build mode is gated — jobs are only created when you explicitly say "Build it".*`;
      }

      const assistantMessage = await storage.createMessage({
        projectId,
        role: "assistant",
        content: assistantContent,
        agentMode: mode,
      });

      res.json({ userMessage, assistantMessage });
    } catch (err) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.post("/api/projects/:id/build", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const { agentMode, content } = req.body;

      if (agentMode !== "build") {
        return res.status(400).json({ message: "Build gate: must be in Build mode" });
      }

      const normalizedContent = (content || "").toLowerCase().trim();
      if (!normalizedContent.includes("build it")) {
        return res.status(400).json({ message: 'Build gate: message must contain "Build it"' });
      }

      const job = await storage.createJob({ projectId, status: "running" });

      const mockLogs = [
        { level: "info", message: "Build started...", delay: 0 },
        { level: "info", message: "Installing dependencies...", delay: 500 },
        { level: "info", message: "npm install completed (mock)", delay: 1500 },
        { level: "info", message: "Compiling TypeScript...", delay: 2000 },
        { level: "warn", message: "Warning: unused variable 'temp' (mock)", delay: 2500 },
        { level: "info", message: "Building application...", delay: 3000 },
        { level: "info", message: "next build completed (mock)", delay: 4000 },
        { level: "info", message: "Running tests...", delay: 4500 },
        { level: "info", message: "All tests passed (mock)", delay: 5500 },
        { level: "info", message: "Build completed successfully!", delay: 6000 },
      ];

      (async () => {
        for (const log of mockLogs) {
          await new Promise((resolve) => setTimeout(resolve, log.delay));
          await storage.createJobLog({
            jobId: job.id,
            level: log.level,
            message: log.message,
          });
        }
        await storage.updateJobStatus(job.id, "completed");
      })();

      const buildMessage = await storage.createMessage({
        projectId,
        role: "assistant",
        content: `[Build Mode] 🔨 Build job #${job.id} has been created and is now running!\n\nSwitch to the **Console** tab to watch the build logs stream in real-time.`,
        agentMode: "build",
      });

      res.json({ job, message: buildMessage });
    } catch (err) {
      res.status(500).json({ message: "Failed to start build" });
    }
  });

  app.get("/api/projects/:id/jobs", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const jobList = await storage.getProjectJobs(projectId);
      res.json(jobList);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/projects/:id/logs/stream", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      });

      let lastLogId = 0;
      const afterParam = req.query.after;
      if (afterParam && typeof afterParam === "string") {
        lastLogId = parseInt(afterParam) || 0;
      }

      const interval = setInterval(async () => {
        try {
          const allLogs = await storage.getProjectJobLogs(projectId);
          const newLogs = allLogs.filter((l) => l.id > lastLogId);
          for (const log of newLogs) {
            res.write(`data: ${JSON.stringify(log)}\n\n`);
            lastLogId = log.id;
          }
        } catch {
          // ignore polling errors
        }
      }, 1000);

      req.on("close", () => {
        clearInterval(interval);
      });
    } catch (err) {
      if (!res.headersSent) {
        res.status(500).json({ message: "Failed to stream logs" });
      }
    }
  });

  app.get("/api/projects/:id/logs", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });

      const userId = getUserId(req);
      if (project.userId !== userId) return res.status(403).json({ message: "Forbidden" });

      const logs = await storage.getProjectJobLogs(projectId);
      res.json(logs);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch logs" });
    }
  });
}
