import { db } from "./db";
import { users, sessions, projects, messages, jobs, jobLogs } from "@shared/schema";
import type {
  User, UpsertUser, Project, InsertProject,
  Message, InsertMessage, Job, InsertJob,
  JobLog, InsertJobLog
} from "@shared/schema";
import { eq, desc, asc } from "drizzle-orm";
import { pool } from "./db";
import connectPgSimple from "connect-pg-simple";
import session from "express-session";

const PgStore = connectPgSimple(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  getUserProjects(userId: number): Promise<Project[]>;
  getProject(projectId: number): Promise<Project | undefined>;
  createProject(data: InsertProject): Promise<Project>;
  deleteProject(projectId: number): Promise<void>;

  getProjectMessages(projectId: number): Promise<Message[]>;
  createMessage(data: InsertMessage): Promise<Message>;

  getProjectJobs(projectId: number): Promise<Job[]>;
  getJob(jobId: number): Promise<Job | undefined>;
  createJob(data: InsertJob): Promise<Job>;
  updateJobStatus(jobId: number, status: string): Promise<Job | undefined>;

  getJobLogs(jobId: number): Promise<JobLog[]>;
  getProjectJobLogs(projectId: number): Promise<JobLog[]>;
  createJobLog(data: InsertJobLog): Promise<JobLog>;

  sessionStore: session.Store;
}

class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PgStore({
      pool: pool as any,
      createTableIfMissing: true,
      tableName: "session",
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [existing] = await db
      .select()
      .from(users)
      .where(eq(users.username, userData.username!));

    if (existing) {
      const [updated] = await db
        .update(users)
        .set({
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
        })
        .where(eq(users.id, existing.id))
        .returning();
      return updated;
    }

    const [created] = await db.insert(users).values(userData).returning();
    return created;
  }

  async getUserProjects(userId: number): Promise<Project[]> {
    return db
      .select()
      .from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.createdAt));
  }

  async getProject(projectId: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, projectId));
    return project;
  }

  async createProject(data: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(data).returning();
    return project;
  }

  async deleteProject(projectId: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, projectId));
  }

  async getProjectMessages(projectId: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.projectId, projectId))
      .orderBy(asc(messages.createdAt));
  }

  async createMessage(data: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(data).returning();
    return message;
  }

  async getProjectJobs(projectId: number): Promise<Job[]> {
    return db
      .select()
      .from(jobs)
      .where(eq(jobs.projectId, projectId))
      .orderBy(desc(jobs.createdAt));
  }

  async getJob(jobId: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, jobId));
    return job;
  }

  async createJob(data: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(data).returning();
    return job;
  }

  async updateJobStatus(jobId: number, status: string): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set({ status })
      .where(eq(jobs.id, jobId))
      .returning();
    return job;
  }

  async getJobLogs(jobId: number): Promise<JobLog[]> {
    return db
      .select()
      .from(jobLogs)
      .where(eq(jobLogs.jobId, jobId))
      .orderBy(asc(jobLogs.createdAt));
  }

  async getProjectJobLogs(projectId: number): Promise<JobLog[]> {
    const projectJobs = await this.getProjectJobs(projectId);
    const jobIds = projectJobs.map(j => j.id);
    if (jobIds.length === 0) return [];

    const allLogs: JobLog[] = [];
    for (const jid of jobIds) {
      const logs = await this.getJobLogs(jid);
      allLogs.push(...logs);
    }
    allLogs.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    return allLogs;
  }

  async createJobLog(data: InsertJobLog): Promise<JobLog> {
    const [log] = await db.insert(jobLogs).values(data).returning();
    return log;
  }
}

export const storage = new DatabaseStorage();
