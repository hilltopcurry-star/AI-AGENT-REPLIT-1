# AI Workspace - Phase 1 (Mock-First)

## Overview
AI-powered development workspace with three agent modes: Discuss, Plan, and Build. Features a build gate that only triggers jobs when in Build mode with explicit "Build it" command. Console streams real DB-backed job logs via SSE.

## Architecture
- **Backend**: Express.js + TypeScript
- **Frontend**: React + Vite + TailwindCSS
- **Database**: PostgreSQL via Drizzle ORM
- **Auth**: Replit Auth (OpenID Connect)
- **Phase**: Mock-first (AI responses are mocked, real AI integration in Phase 2)

## Project Structure
```
server/
  index.ts                     # Express server entry
  routes.ts                    # API routes (projects, messages, builds, SSE logs)
  storage.ts                   # Database operations (IStorage)
  db.ts                        # Drizzle database connection + table creation
  vite.ts                      # Vite dev server + static serving
  replit_integrations/auth/    # Replit Auth (OIDC + passport)
client/
  index.html                   # HTML entry
  src/
    main.tsx                   # React entry
    App.tsx                    # Router (Landing, Projects, ProjectWorkspace)
    pages/
      landing.tsx              # Landing page (unauthenticated)
      projects.tsx             # Projects home/list page
      project-workspace.tsx    # Project workspace with Chat/Console/Database tabs
    components/
      sidebar.tsx              # Project list sidebar with CRUD
      theme-provider.tsx       # Dark/Light mode
      toaster.tsx              # Toast notifications
      ui/                      # Shadcn-style UI components
    hooks/
      use-auth.ts              # Auth hook
      use-toast.ts             # Toast hook
    lib/
      queryClient.ts           # React Query + fetch helpers
      utils.ts                 # Tailwind utilities
shared/
  schema.ts                    # Drizzle schema (users, sessions, projects, messages, jobs, jobLogs)
```

## Database Schema
- users: id (serial), username, email, firstName, lastName, profileImageUrl, createdAt
- sessions: id (text), userId, expiresAt
- projects: id (serial), userId, name, description, createdAt
- messages: id (serial), projectId, role, content, agentMode, createdAt
- jobs: id (serial), projectId, status, createdAt
- job_logs: id (serial), jobId, level, message, createdAt

## API Routes
- GET /api/health - Health check (returns {"ok": true})
- GET /api/auth/user - Current user
- GET/POST /api/projects - List/create projects
- GET/DELETE /api/projects/:id - Get/delete project
- GET/POST /api/projects/:id/messages - Get/send messages (with agentMode)
- POST /api/projects/:id/build - Trigger build (gated: requires Build mode + "Build it")
- GET /api/projects/:id/jobs - List jobs
- GET /api/projects/:id/logs/stream - SSE stream of job logs
- GET /api/projects/:id/logs - Get all logs
- /api/login, /api/logout, /api/callback - Replit Auth

## Agent Modes
- **Discuss**: Brainstorm ideas, get AI analysis (mock in Phase 1)
- **Plan**: Create structured action plans (mock in Phase 1)
- **Build**: Trigger builds with gated process (mock build runner in Phase 1)

## Build Gate
- Jobs are ONLY created when:
  1. Agent mode is set to "Build"
  2. User explicitly says "Build it"
- Build creates mock job logs that stream via SSE to the Console tab

## Tabs
- **Chat**: Message interface with agent mode selector
- **Console**: Real-time SSE streaming of DB-backed job logs
- **Database**: Read-only view of build jobs

## Scripts
- `npm run dev` - Development server (port 5000)
- `npm run build` - Build for production
- `npm run start` - Production server

## Environment
- DATABASE_URL - PostgreSQL connection string
- SESSION_SECRET - Session encryption
