import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import {
  MessageSquare, Terminal, Database,
  Send, Hammer, AlertTriangle, CheckCircle2,
  Clock, XCircle, Loader2
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { apiRequest, queryClient } from "../lib/queryClient";
import type { Project, Message, Job, JobLog } from "@shared/schema";

type AgentMode = "discuss" | "plan" | "build";

const modeConfig: Record<AgentMode, { label: string; color: string; bgColor: string }> = {
  discuss: { label: "Discuss", color: "text-blue-500", bgColor: "bg-blue-500/10" },
  plan: { label: "Plan", color: "text-amber-500", bgColor: "bg-amber-500/10" },
  build: { label: "Build", color: "text-green-500", bgColor: "bg-green-500/10" },
};

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
  return res.json();
}

export default function ProjectWorkspace() {
  const [, params] = useRoute("/projects/:id");
  const projectId = params?.id ? parseInt(params.id) : null;
  const [agentMode, setAgentMode] = useState<AgentMode>("discuss");
  const [input, setInput] = useState("");
  const [activeTab, setActiveTab] = useState("chat");
  const [streamLogs, setStreamLogs] = useState<JobLog[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const prevProjectIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (projectId !== prevProjectIdRef.current) {
      setStreamLogs([]);
      prevProjectIdRef.current = projectId;
    }
  }, [projectId]);

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
    queryFn: () => fetchJson<Project>(`/api/projects/${projectId}`),
    enabled: !!projectId,
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/projects", projectId, "messages"],
    queryFn: () => fetchJson<Message[]>(`/api/projects/${projectId}/messages`),
    enabled: !!projectId,
  });

  const { data: jobsList = [] } = useQuery<Job[]>({
    queryKey: ["/api/projects", projectId, "jobs"],
    queryFn: () => fetchJson<Job[]>(`/api/projects/${projectId}/jobs`),
    enabled: !!projectId,
  });

  const sendMutation = useMutation({
    mutationFn: async (payload: { content: string; agentMode: string }) => {
      const isBuildTrigger =
        payload.agentMode === "build" &&
        payload.content.toLowerCase().includes("build it");

      const res = await apiRequest("POST", `/api/projects/${projectId}/messages`, payload);
      const result = await res.json();

      if (isBuildTrigger) {
        const buildRes = await apiRequest("POST", `/api/projects/${projectId}/build`, {
          agentMode: "build",
          content: payload.content,
        });
        const buildResult = await buildRes.json();
        return { ...result, buildTriggered: true, job: buildResult.job };
      }

      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "messages"] });
      if (data?.buildTriggered) {
        queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "jobs"] });
        setActiveTab("console");
      }
    },
  });

  const buildMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/projects/${projectId}/build`, {
        agentMode: "build",
        content: "Build it",
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "jobs"] });
      setActiveTab("console");
    },
  });

  const handleSend = useCallback(() => {
    if (!input.trim() || !projectId) return;
    sendMutation.mutate({ content: input, agentMode });
    setInput("");
  }, [input, projectId, agentMode, sendMutation]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [streamLogs]);

  useEffect(() => {
    if (!projectId) return;

    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    if (activeTab !== "console") return;

    fetchJson<JobLog[]>(`/api/projects/${projectId}/logs`).then((logs) => {
      setStreamLogs(logs);

      const lastId = logs.length > 0 ? logs[logs.length - 1].id : 0;
      const es = new EventSource(`/api/projects/${projectId}/logs/stream?after=${lastId}`);
      eventSourceRef.current = es;

      es.onmessage = (event) => {
        try {
          const log: JobLog = JSON.parse(event.data);
          setStreamLogs((prev) => {
            if (prev.some((l) => l.id === log.id)) return prev;
            return [...prev, log];
          });
        } catch {
          // ignore
        }
      };

      es.onerror = () => {
        es.close();
      };
    });

    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [projectId, activeTab]);

  if (!projectId) {
    return (
      <div className="flex-1 flex items-center justify-center" data-testid="text-no-project-selected">
        <p className="text-muted-foreground">Select a project</p>
      </div>
    );
  }

  if (projectLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-muted-foreground">Project not found</p>
      </div>
    );
  }

  const statusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="w-4 h-4 text-muted-foreground" />;
      case "running": return <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />;
      case "completed": return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case "failed": return <XCircle className="w-4 h-4 text-destructive" />;
      default: return null;
    }
  };

  const logLevelColor = (level: string) => {
    switch (level) {
      case "error": return "text-red-400";
      case "warn": return "text-yellow-400";
      default: return "text-green-400";
    }
  };

  return (
    <div className="flex-1 flex flex-col h-screen" data-testid="project-workspace">
      <div className="border-b border-border px-6 py-3 flex items-center justify-between bg-background">
        <div>
          <h2 className="font-semibold text-lg" data-testid="text-project-name">{project.name}</h2>
          {project.description && (
            <p className="text-xs text-muted-foreground" data-testid="text-project-description">{project.description}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {(["discuss", "plan", "build"] as AgentMode[]).map((mode) => (
            <Button
              key={mode}
              variant={agentMode === mode ? "default" : "outline"}
              size="sm"
              onClick={() => setAgentMode(mode)}
              className={agentMode === mode ? "" : modeConfig[mode].color}
              data-testid={`button-mode-${mode}`}
            >
              {modeConfig[mode].label}
            </Button>
          ))}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
        <div className="border-b border-border px-6">
          <TabsList className="h-10">
            <TabsTrigger value="chat" className="gap-1.5" data-testid="tab-chat">
              <MessageSquare className="w-4 h-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="console" className="gap-1.5" data-testid="tab-console">
              <Terminal className="w-4 h-4" />
              Console
            </TabsTrigger>
            <TabsTrigger value="database" className="gap-1.5" data-testid="tab-database">
              <Database className="w-4 h-4" />
              Database
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="chat" className="flex-1 flex flex-col overflow-hidden mt-0">
          <ScrollArea className="flex-1 p-6">
            <div className="max-w-3xl mx-auto space-y-4">
              {messagesLoading ? (
                <div className="flex items-center justify-center py-16">
                  <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-16 space-y-3" data-testid="text-empty-chat">
                  <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto" />
                  <h3 className="text-lg font-semibold">Start a conversation</h3>
                  <p className="text-sm text-muted-foreground max-w-md mx-auto">
                    Use <span className={modeConfig.discuss.color}>Discuss</span> to brainstorm,{" "}
                    <span className={modeConfig.plan.color}>Plan</span> to create action plans, or{" "}
                    <span className={modeConfig.build.color}>Build</span> to trigger builds.
                  </p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    data-testid={`message-${msg.id}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-medium opacity-70">
                          {msg.role === "user" ? "You" : "AI Agent"}
                        </span>
                        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${modeConfig[msg.agentMode as AgentMode]?.color || ""}`}>
                          {modeConfig[msg.agentMode as AgentMode]?.label || msg.agentMode}
                        </Badge>
                      </div>
                      <div className="text-sm whitespace-pre-wrap">{msg.content}</div>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          <div className="border-t border-border p-4 bg-background">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-2 mb-2">
                <Badge className={`${modeConfig[agentMode].bgColor} ${modeConfig[agentMode].color} border-0`}>
                  {modeConfig[agentMode].label} Mode
                </Badge>
                {agentMode === "build" && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    Say "Build it" or use the Build button to trigger a build
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={
                    agentMode === "build"
                      ? 'Type a message or say "Build it" to start a build...'
                      : `Message in ${modeConfig[agentMode].label} mode...`
                  }
                  className="min-h-[44px] max-h-[120px] resize-none"
                  data-testid="input-message"
                />
                <div className="flex flex-col gap-1">
                  <Button
                    onClick={handleSend}
                    disabled={!input.trim() || sendMutation.isPending}
                    size="icon"
                    data-testid="button-send"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                  {agentMode === "build" && (
                    <Button
                      onClick={() => buildMutation.mutate()}
                      disabled={buildMutation.isPending}
                      size="icon"
                      variant="outline"
                      className="text-green-500"
                      data-testid="button-build"
                    >
                      <Hammer className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="console" className="flex-1 flex flex-col overflow-hidden mt-0">
          <div className="flex-1 bg-gray-950 text-gray-100 font-mono text-sm overflow-auto p-4" data-testid="console-output">
            {streamLogs.length === 0 ? (
              <div className="text-gray-500 flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <span>Waiting for build logs... Trigger a build in Build mode to see output here.</span>
              </div>
            ) : (
              streamLogs.map((log) => (
                <div key={log.id} className="flex gap-2 py-0.5" data-testid={`log-entry-${log.id}`}>
                  <span className="text-gray-600 text-xs min-w-[80px]">
                    {new Date(log.createdAt).toLocaleTimeString()}
                  </span>
                  <span className={`text-xs uppercase min-w-[40px] ${logLevelColor(log.level)}`}>
                    [{log.level}]
                  </span>
                  <span className={logLevelColor(log.level)}>{log.message}</span>
                </div>
              ))
            )}
            <div ref={consoleEndRef} />
          </div>
        </TabsContent>

        <TabsContent value="database" className="flex-1 overflow-auto mt-0 p-6">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2" data-testid="text-database-title">
              <Database className="w-5 h-5" />
              Jobs
            </h3>
            {jobsList.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground" data-testid="text-no-jobs">No build jobs yet. Trigger a build in Build mode.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {jobsList.map((job) => (
                  <Card key={job.id} data-testid={`card-job-${job.id}`}>
                    <CardHeader className="py-3 px-4">
                      <CardTitle className="text-sm flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          {statusIcon(job.status)}
                          Job #{job.id}
                        </span>
                        <div className="flex items-center gap-2">
                          <Badge variant={job.status === "completed" ? "default" : job.status === "failed" ? "destructive" : "secondary"}>
                            {job.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(job.createdAt).toLocaleString()}
                          </span>
                        </div>
                      </CardTitle>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
