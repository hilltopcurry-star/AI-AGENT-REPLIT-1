import { Code2, Cpu, Terminal, Layers, Hammer, Sparkles } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background" data-testid="landing-page">
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-background/80 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 className="w-7 h-7 text-primary" />
            <span className="text-xl font-bold">AI Workspace</span>
          </div>
          <a
            href="/api/login"
            className="px-5 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity text-sm"
            data-testid="button-login"
          >
            Sign In
          </a>
        </div>
      </nav>

      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
              Your AI{" "}
              <span className="text-primary">Development</span>{" "}
              Workspace
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg">
              Discuss ideas, plan architecture, and build projects with AI-powered agent modes. From concept to code in minutes.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/api/login"
                className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-opacity"
                data-testid="button-get-started"
              >
                Get Started Free
              </a>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground pt-2">
              <span className="flex items-center gap-1.5">
                <Cpu className="w-4 h-4" /> AI-Powered
              </span>
              <span className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4" /> Real-time Logs
              </span>
            </div>
          </div>

          <div className="relative">
            <div className="bg-card border border-border rounded-2xl p-6 shadow-xl">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-border">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-yellow-400" />
                <div className="w-3 h-3 rounded-full bg-green-400" />
                <span className="ml-2 text-sm text-muted-foreground">AI Workspace</span>
              </div>
              <div className="space-y-3">
                <div className="flex gap-2 items-center text-sm">
                  <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-500 font-medium text-xs">Discuss</span>
                  <span className="text-muted-foreground">Explore ideas with AI</span>
                </div>
                <div className="flex gap-2 items-center text-sm">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 font-medium text-xs">Plan</span>
                  <span className="text-muted-foreground">Create detailed action plans</span>
                </div>
                <div className="flex gap-2 items-center text-sm">
                  <span className="px-2 py-0.5 rounded bg-green-500/10 text-green-500 font-medium text-xs">Build</span>
                  <span className="text-muted-foreground">Generate code & run builds</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Three Modes, One Workflow
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Sparkles,
                title: "Discuss Mode",
                desc: "Brainstorm ideas and get AI analysis. Explore requirements before committing to a plan.",
              },
              {
                icon: Layers,
                title: "Plan Mode",
                desc: "Create structured action plans. Define architecture, components, and implementation steps.",
              },
              {
                icon: Hammer,
                title: "Build Mode",
                desc: "Trigger builds with a gated process. Watch real-time logs stream in the console.",
              },
              {
                icon: Terminal,
                title: "Live Console",
                desc: "Stream build logs in real-time via SSE. See every step of your build process as it happens.",
              },
              {
                icon: Cpu,
                title: "Job Tracking",
                desc: "Track all build jobs with status, timestamps, and detailed logs in the database view.",
              },
              {
                icon: Code2,
                title: "Mock-First",
                desc: "Start with mock responses, upgrade to real AI code generation in Phase 2.",
              },
            ].map((feature, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-xl p-6 hover:shadow-md transition-shadow"
              >
                <feature.icon className="w-10 h-10 text-primary mb-4" />
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-8 px-6 border-t border-border">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-sm text-muted-foreground">
          <span>AI Workspace</span>
          <span>Phase 1 - Mock-First</span>
        </div>
      </footer>
    </div>
  );
}
