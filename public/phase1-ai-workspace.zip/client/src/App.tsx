import { Switch, Route } from "wouter";
import { useAuth } from "./hooks/use-auth";
import LandingPage from "./pages/landing";
import ProjectsPage from "./pages/projects";
import ProjectWorkspace from "./pages/project-workspace";
import Sidebar from "./components/sidebar";

function App() {
  const { isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background" data-testid="loading-screen">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground text-sm">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <Switch>
        <Route path="/" component={ProjectsPage} />
        <Route path="/projects/:id" component={ProjectWorkspace} />
        <Route>
          <div className="flex-1 flex items-center justify-center">
            <p className="text-muted-foreground">Page not found</p>
          </div>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
